        <div id="L1">
            <p class="p1 p2">推荐</p>
            <span><a id="a1_index" class="a1" href="#index">发现音乐</a></span>
            <span><a id="a1_fm" class="a1" href="#fm">私人FM</a></span>
            <span><a id="a1_mv" class="a1" href="#mv">MV</a></span>
            <span><a id="a1_friend" class="a1" href="#friend">朋友</a></span>
            <p class="p1 p2">我的音乐</p>
            <span><a id="a1_disk" class="a1" href="#disk">我的音乐云盘</a></span>
            <span><a id="a1_upload" class="a1" href="#upload">上传音乐</a></span>
            <span><a id="a1_share" class="a1" href="#share">我的分享</a></span>
            <span><a id="a1_favor" class="a1" href="#favor">我的收藏</a></span>
            <p class="p1 p2">用户中心</p>
            <span id="s1_1" style="display:none"><a id="a1_info" class="a1" href="#info">用户名</a></span>
            <span id="s1_2" style="display:none"><a id="a1_logout" class="a1" href="#logout">退出账号</a></span>
            <span id="s2_1"><a id="a1_login" class="a1" href="#login">登录</a></span>
            <span id="s2_2"><a id="a1_reg" class="a1" href="#reg">注册</a></span>
            <span><a id="a1_feedback" class="a1" href="#feedback">意见反馈</a></span>
            <p class="p1 p2">滑稽云音乐官方APP即将上线，敬请关注！</p>
        </div>
        <p style="visibility: hidden">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur deserunt enim ex explicabo facere in mollitia neque quidem quos recusandae rem, saepe ut. Delectus ducimus earum excepturi sunt, ullam vero!
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium animi aperiam aut beatae commodi cum dignissimos ea eos error labore laboriosam minima, molestiae quaerat quas quasi sit suscipit tempore voluptatum!
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium animi aperiam aut beatae commodi cum dignissimos ea eos error labore laboriosam minima, molestiae quaerat quas quasi sit suscipit tempore voluptatum!
        </p>
        <!-- TODO 2019-07-06 06:15:32
            To：Jessica Lee
                这该死的，老大说要加上固件更新功能，明天就要上线了！？？？
                通宵还没写完，我困的不行了回去睡觉（提刀上门），代码先放在这。
                今天上班你继续把代码写完，虽然你还是实习生，不过我相信你的水平。
                记住了，安全为首！！！
                还有一点，写完记得删掉备注！！！
            From：Alan Wang
        <p class="p1 p2">管理员</p>
        <span><a class="a1" href="#firmware">固件更新</a></span>
        -->
